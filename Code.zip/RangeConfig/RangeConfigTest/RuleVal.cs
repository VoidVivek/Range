﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RangeConfigTest
{
    public class RuleVal
    {
        public Aveva.CounterRange.Models.Rule _rule;
        public DataTable _dt;

    }
}
